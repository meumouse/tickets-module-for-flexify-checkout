/**
 * Ticket step helpers for Flexify Checkout.
 *
 * @since 1.0.0
 * @version 1.2.0
 * @package MeuMouse.com
 */
(function (window, $) {
    'use strict';

    /**
     * Time to live Cookies
     *
     * @since 1.0.0
     * @version 1.2.0
     * @return {int}
     */
    var COOKIE_TTL_DAYS = 7;

    /**
     * Plugin params
     *
     * @since 1.0.0
     * @version 1.2.0
     * @return {object}
     */
    var params = window.fcw_ticket_fields_params || {};

    /**
     * Field prefixes array
     *
     * @since 1.2.0
     * @return {Array}
     */
    var ticketFieldPrefixes = [
        'billing_first_name_',
        'billing_last_name_',
        'billing_cpf_',
        'billing_phone_',
        'billing_email_',
    ];

    /**
     * Fields to mask / validate
     *
     * @since 1.0.0
     * @version 1.2.0
     * @return {Array}
     */
    var fieldIds = [];

    /**
     * Notice selector
     *
     * @since 1.2.0
     * @return {string}
     */
    var noticeSelector = '.flexify-ticket-errors';

    /**
     * Inline error class used by this module
     *
     * @since 1.2.0
     * @return {string}
     */
    var inlineErrorClass = 'flexify-tkt-inline-error';

    /**
     * Basic cookie store
     *
     * @since 1.0.0
     * @version 1.2.0
     */
    var CookieStore = {
        set: function (name, value, days) {
            var expires = '';
            var ttl = days || COOKIE_TTL_DAYS;

            if (ttl) {
                var date = new Date();
                date.setTime(date.getTime() + ttl * 24 * 60 * 60 * 1000);
                expires = '; expires=' + date.toUTCString();
            }

            document.cookie = name + '=' + (value || '') + expires + '; path=/';
        },

        get: function (name) {
            var nameEQ = name + '=';
            var cookies = document.cookie.split(';');

            for (var i = 0; i < cookies.length; i++) {
                var cookie = cookies[i];

                while (cookie.charAt(0) === ' ') {
                    cookie = cookie.substring(1, cookie.length);
                }

                if (cookie.indexOf(nameEQ) === 0) {
                    return cookie.substring(nameEQ.length, cookie.length);
                }
            }

            return null;
        }
    };

    /**
     * Attach masks to CPF and phone fields
     *
     * @since 1.0.0
     * @version 1.2.0
     */
    function applyMaskForField($field, fieldId) {
        if (!$field.is('input, textarea')) {
            return;
        }

        if (fieldId.indexOf('billing_cpf_') !== -1 && $.fn.mask) {
            $field.mask('000.000.000-00');
        }

        if (fieldId.indexOf('billing_phone_') !== -1 && $.fn.mask) {
            // Skip phone mask when using intl-tel-input
            if ($field.closest('.flexify-intl-phone').length) {
                return;
            }

            $field.mask('(00) 00000-0000');
        }
    }

    /**
     * Find ticket fields currently in DOM
     *
     * @since 1.2.0
     * @version 1.2.2
     * @return {Array}
     */
    function findTicketFields() {
        var ids = [];
        var scope = $('.flexify-ticket-fields');

        if ( ! scope.length ) {
            return ids;
        }

        ticketFieldPrefixes.forEach( function(prefix) {
           scope.find('input[id^="' + prefix + '"]').each( function() {
                var id = this.id;

                // For phone fields, accept only billing_phone_N (no _full)
                if ( prefix === 'billing_phone_' ) {
                    if ( ! /^billing_phone_\d+$/.test(id) ) {
                        return;
                    }
                }

                ids.push(id);
            });
        });

        return ids;
    }

    /**
     * Refresh list of ticket fields
     *
     * @since 1.2.0
     */
    function refreshFieldIds() {
        fieldIds = findTicketFields();

        if ( ! fieldIds.length && params.fields_to_mask ) {
            fieldIds = params.fields_to_mask;
        }
    }

    /**
     * Load cached values from cookies
     *
     * @since 1.0.0
     * @version 1.2.0
     */
    function loadCachedValues() {
        fieldIds.forEach( function(fieldId) {
            var cachedValue = CookieStore.get(fieldId);

            if ( cachedValue ) {
                $('#' + fieldId).val(cachedValue);
            }
        });
    }

    /**
     * Cache a single field value
     *
     * @since 1.0.0
     * @version 1.2.0
     */
    function cacheFieldValue(fieldId) {
        var fieldValue = $('#' + fieldId).val();
        CookieStore.set(fieldId, fieldValue, COOKIE_TTL_DAYS);
    }

    /**
     * Add masks and cache handlers for ticket fields
     *
     * @since 1.2.0
     */
    function bindCacheHandlers() {
        fieldIds.forEach(function (fieldId) {
            var $field = $('#' + fieldId);

            applyMaskForField($field, fieldId);
            cacheFieldValue(fieldId);

            $field.off('.flexifyTicketCache');
            $field.on('input.flexifyTicketCache', function () {
                cacheFieldValue(fieldId);

                // Any change re-enables next step button
                $('button.flexify-button[data-step-next]').prop('disabled', false);
            });
        });
    }

    /**
     * CPF validation using real check digits algorithm
     *
     * @since 1.2.1
     * @return {Boolean}
     */
    function isValidCPF(cpf) {
        cpf = (cpf || '').replace(/\D+/g, '');

        if (!cpf || cpf.length !== 11) return false;

        // Reject repeated digits (00000000000, 11111111111...)
        if (/^(\d)\1+$/.test(cpf)) return false;

        // Validate first check digit
        var sum = 0;
        for (var i = 0; i < 9; i++) sum += parseInt(cpf.charAt(i)) * (10 - i);
        var firstDigit = (sum * 10) % 11;
        if (firstDigit === 10 || firstDigit === 11) firstDigit = 0;
        if (firstDigit !== parseInt(cpf.charAt(9))) return false;

        // Validate second check digit
        sum = 0;
        for (i = 0; i < 10; i++) sum += parseInt(cpf.charAt(i)) * (11 - i);
        var secondDigit = (sum * 10) % 11;
        if (secondDigit === 10 || secondDigit === 11) secondDigit = 0;
        if (secondDigit !== parseInt(cpf.charAt(10))) return false;

        return true;
    }

    /**
     * Validate email using regex
     *
     * @since 1.2.1
     * @return {Boolean}
     */
    function isValidEmail(email) {
        var regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
        return regex.test(email);
    }

    /**
     * Normalize to digits only
     *
     * @since 1.2.0
     */
    function normalizeDigits(value) {
        return (value || '').replace(/\D+/g, '');
    }

    /**
     * Clear validation feedback
     *
     * @since 1.2.0
     * @version 1.2.1
     */
    function removeValidationFeedback() {
        $('.flexify-checkout-notice.error').remove();

        fieldIds.forEach( function(fieldId) {
            var $field = $('#' + fieldId);
            var $row = $field.closest('.form-row');

            $field.removeClass('woocommerce-invalid').removeAttr('aria-invalid');

            $row.removeClass('woocommerce-invalid wc-invalid-required-field');
            $row.find('.' + inlineErrorClass).remove();
        });
    }

    /**
     * Show global WooCommerce-style messages
     * Using the same structure as error.php template.
     *
     * @since 1.2.0
     */
    function showValidationMessages(messages) {
        if (!messages || !messages.length) {
            return;
        }

        // Remove duplicates
        var uniqueMessages = [];
        messages.forEach(function (msg) {
            if (uniqueMessages.indexOf(msg) === -1) {
                uniqueMessages.push(msg);
            }
        });

        if (!uniqueMessages.length) {
            return;
        }

        var $checkoutForm = $('form.checkout');
        var wrapper = $checkoutForm.find('.woocommerce-notices-wrapper');

        if (!wrapper.length) {
            wrapper = $('<div class="woocommerce-notices-wrapper"></div>');
            $checkoutForm.prepend(wrapper);
        }

        // Remove previous notices from this module
        wrapper.find('.flexify-checkout-notice.error').remove();

        uniqueMessages.forEach(function (message) {
            var $notice = $('<div/>', {
                'class': 'woocommerce-error flexify-checkout-notice error',
                'role': 'alert'
            });

            // Text content only (no HTML to escape)
            $notice.append(document.createTextNode(message));

            var $closeBtn = $('<button/>', {
                'class': 'close-notice btn-close btn-close-white',
                'type': 'button'
            });

            $notice.append($closeBtn);
            wrapper.prepend($notice);
        });

        window.scrollTo({
            top: $checkoutForm.offset().top,
            behavior: 'smooth'
        });
    }

    /**
     * Show inline error messages per field, without duplicates
     *
     * @since 1.2.0
     * @version 1.2.1
     * @param {Object} fieldMessages | { fieldId: [messages] }
     */
    function showInlineFieldMessages(fieldMessages) {
        Object.keys(fieldMessages).forEach( function(fieldId) {
            var msgs = fieldMessages[fieldId];

            if ( ! msgs || ! msgs.length ) {
                return;
            }

            var $field = $('#' + fieldId);
            var $row = $field.closest('.form-row');
            var $existing = $row.find('span.error').first();

            if ($existing.length) {
                $existing.text(msgs[0]).addClass(inlineErrorClass);
            } else {
                var $error = $('<span/>', {
                    'class': 'error ' + inlineErrorClass,
                    text: msgs[0]
                });

                $row.append($error);
            }

            $field.addClass('woocommerce-invalid').attr('aria-invalid', 'true');
            $row.addClass('woocommerce-invalid').addClass('woocommerce-invalid-required-field');
        });
    }

    /**
     * Validate unique values and build both global and inline messages
     *
     * @since 1.2.0
     * @param {Array} entries        | [{ id: 'billing_cpf_1', value: '123' }, ...]
     * @param {String} fieldLabel    | "CPF", "telefone", "e-mail"
     * @param {Array} globalMessages | Will be mutated
     * @param {Object} fieldMessages | { fieldId: [messages] } will be mutated
     */
    function validateUniqueValues(entries, fieldLabel, globalMessages, fieldMessages) {
        if (!entries || !entries.length) {
            return;
        }

        var grouped = {};
        var hasDuplicates = false;

        entries.forEach(function (entry) {
            if (!entry.value) {
                return;
            }

            if (!grouped[entry.value]) {
                grouped[entry.value] = [];
            }

            grouped[entry.value].push(entry.id);
        });

        Object.keys(grouped).forEach(function (value) {
            var ids = grouped[value];

            if (ids.length > 1) {
                hasDuplicates = true;

                ids.forEach(function (fieldId) {
                    var msg =
                        'O ' +
                        fieldLabel +
                        ' informado para este ingresso já foi utilizado em outro ingresso. Informe um ' +
                        fieldLabel +
                        ' diferente.';

                    if (!fieldMessages[fieldId]) {
                        fieldMessages[fieldId] = [];
                    }

                    fieldMessages[fieldId].push(msg);

                    var $field = $('#' + fieldId);
                    var $row = $field.closest('.form-row');

                    $field
                        .addClass('woocommerce-invalid')
                        .attr('aria-invalid', 'true');

                    $row
                        .addClass('woocommerce-invalid')
                        .addClass('woocommerce-invalid-required-field');
                });
            }
        });

        if (hasDuplicates) {
            globalMessages.push(
                'Existem ingressos com ' +
                    fieldLabel +
                    ' repetido. Cada ingresso deve possuir um ' +
                    fieldLabel +
                    ' único.'
            );
        }
    }

    /**
     * Validate ticket fields (required + unique + CPF + email)
     *
     * @since 1.2.0
     * @version 1.2.1
     */
    function validateTicketFields() {
        refreshFieldIds();
        bindCacheHandlers();
        removeValidationFeedback();

        var messages = [];
        var fieldMessages = {};

        var cpfEntries = [];
        var emailEntries = [];
        var phoneEntries = [];

        fieldIds.forEach( function(fieldId) {
            var $field = $('#' + fieldId);
            var value = $.trim($field.val() || '');
            var $row = $field.closest('.form-row');

            var label = $.trim($row.find('label').text()).replace(/\*$/, '');

            /** Required field validation */
            if (!value) {
                var msg = label + ' é um campo obrigatório.';

                messages.push(msg);
                fieldMessages[fieldId] = fieldMessages[fieldId] || [];
                fieldMessages[fieldId].push(msg);
            }

            /** Collect CPF */
            if (fieldId.indexOf('billing_cpf_') !== -1 && value) {
                var cpf = normalizeDigits(value);

                if (!isValidCPF(cpf)) {
                    var invalidCPFmsg = 'O CPF informado é inválido.';

                    messages.push(invalidCPFmsg);
                    fieldMessages[fieldId] = fieldMessages[fieldId] || [];
                    fieldMessages[fieldId].push(invalidCPFmsg);
                }

                cpfEntries.push({ id: fieldId, value: cpf });
            }

            /** Collect email and validate format */
            if (fieldId.indexOf('billing_email_') !== -1 && value) {
                var email = value.toLowerCase();

                if (!isValidEmail(email)) {
                    var invalidEmailMsg = 'O e-mail informado é inválido.';

                    messages.push(invalidEmailMsg);
                    fieldMessages[fieldId] = fieldMessages[fieldId] || [];
                    fieldMessages[fieldId].push(invalidEmailMsg);
                }

                emailEntries.push({ id: fieldId, value: email });
            }

            /** Collect phone for duplicate validation */
            if (fieldId.indexOf('billing_phone_') !== -1 && value) {
                var $field = $('#' + fieldId);
                var isIntl = $field.closest('.flexify-intl-phone').length > 0;
                var phoneValid = true;

                if (isIntl) {
                    // Validate using intl-tel-input
                    phoneValid = isValidIntlPhone($field);
                } else {
                    // Validate using standard Brazilian format
                    phoneValid = isValidBrazilPhone(value);
                }

                if ( ! phoneValid ) {
                    var invalidPhoneMsg = 'Por favor, insira um número de telefone válido.';

                    messages.push(invalidPhoneMsg);

                    fieldMessages[fieldId] = fieldMessages[fieldId] || [];
                    fieldMessages[fieldId].push(invalidPhoneMsg);
                }

                // Add entry for duplicate checking
                phoneEntries.push({
                    id: fieldId,
                    value: normalizeDigits(value)
                });
            }
        });

        /** Duplicate validations */
        validateUniqueValues(cpfEntries, 'CPF', messages, fieldMessages);
        validateUniqueValues(phoneEntries, 'telefone', messages, fieldMessages);
        validateUniqueValues(emailEntries, 'e-mail', messages, fieldMessages);

        return {
            isValid: messages.length === 0,
            messages: messages,
            fieldMessages: fieldMessages
        };
    }

    /**
     * Handle step change and block step when invalid
     *
     * @since 1.2.0
     * @version 1.2.0
     */
    function handleStepChange(nativeEvent) {
        var validation = validateTicketFields();

        if (validation.isValid) {
            return true;
        }

        if (nativeEvent) {
            nativeEvent.preventDefault();
            nativeEvent.stopPropagation();
        }

        // Disable next button until user edits something
        var btn = nativeEvent && nativeEvent.target
            ? nativeEvent.target.closest('button.flexify-button[data-step-next]')
            : null;

        if (btn) {
            btn.setAttribute('disabled', 'disabled');
        }

        // Inline + global messages
        showInlineFieldMessages(validation.fieldMessages);
        showValidationMessages(validation.messages);

        return false;
    }

    /**
     * Bind validation to "Continuar para pagamento" button
     * using capture phase so we run before Flexify handlers.
     *
     * @since 1.2.0
     */
    function bindStepValidation() {
        document.addEventListener(
            'click',
            function (e) {
                var btn = e.target.closest('button.flexify-button[data-step-next][data-step-show="3"]');

                if (!btn) {
                    return;
                }

                handleStepChange(e);
            },
            true // capture
        );
    }

        /**
     * Ensure hidden intl phone field billing_phone_{i}_full exists
     *
     * @since 1.2.0
     * @param {jQuery} $field Phone input
     * @return {jQuery|null}
     */
    function ensureIntlPhoneFullField($field) {
        if (!$field || !$field.length) {
            return null;
        }

        var id = $field.attr('id') || '';
        var match = id.match(/^billing_phone_(\d+)$/);

        if (!match) {
            return null;
        }

        var index = match[1];
        var fullId = 'billing_phone_' + index + '_full';
        var $row = $field.closest('.form-row');
        var $hidden = $row.find('#' + fullId);

        if (!$hidden.length) {
            $hidden = $('<input/>', {
                type: 'hidden',
                id: fullId,
                name: fullId
            });

            // Pode ser no final da .form-row mesmo
            $row.append($hidden);
        }

        return $hidden;
    }

    /**
     * Update hidden intl phone field with E.164-like value
     *
     * @since 1.2.0
     * @param {jQuery} $field Phone input
     */
    function updateIntlPhoneFull($field) {
        if (!$field || !$field.length) {
            return;
        }

        var $hidden = ensureIntlPhoneFullField($field);

        if (!$hidden || !$hidden.length) {
            return;
        }

        // Apenas dígitos do input
        var raw = normalizeDigits($field.val());

        // Tentar pegar o DDI pelo wrapper .iti
        var dialCode = '';
        var $iti = $field.closest('.iti');

        if ($iti.length) {
            var $dial = $iti.find('.iti__selected-dial-code').first();

            if ($dial.length) {
                dialCode = $.trim($dial.text().replace(/\s+/g, '')); // ex: '+55'
            }
        }

        // Se intl-tel-input estiver disponível, usar a API (melhor)
        if (!dialCode && window.intlTelInputGlobals && typeof window.intlTelInputGlobals.getInstance === 'function') {
            var instance = window.intlTelInputGlobals.getInstance($field[0]);

            if (instance && typeof instance.getNumber === 'function') {
                var number = instance.getNumber(); // já vem em E.164

                $hidden.val(number || '');
                return;
            }
        }

        if (dialCode && raw) {
            // dialCode já começa com '+'
            $hidden.val(dialCode + raw);
        } else {
            $hidden.val('');
        }
    }

    /**
     * Bind handlers to keep billing_phone_{i}_full synced
     *
     * @since 1.2.0
     */
    function bindIntlPhoneFullHandlers() {
        // Delegated events (funciona mesmo após fragmentos de checkout)
        $(document)
            .off('.flexifyTicketIntl')
            .on(
                'input.flexifyTicketIntl change.flexifyTicketIntl countrychange.flexifyTicketIntl',
                '.flexify-intl-phone input[id^="billing_phone_"]',
                function () {
                    updateIntlPhoneFull($(this));
                }
            );

        // Sync inicial para campos já presentes
        $('.flexify-intl-phone input[id^="billing_phone_"]').each(function () {
            updateIntlPhoneFull($(this));
        });
    }

    /**
     * Validate Brazilian phone format when intl-tel-input is not active
     *
     * Accepts (00) 0000-0000 or (00) 00000-0000
     * Also validates length (10 or 11 digits)
     * Rejects invalid repeated sequences (11111111111)
     *
     * @since 1.2.1
     * @param {String} phone
     * @return {Boolean}
     */
    function isValidBrazilPhone(phone) {
        var digits = normalizeDigits(phone);

        if (digits.length < 10 || digits.length > 11) {
            return false;
        }

        // Reject repeated numbers like 00000000000 or 1111111111
        if (/^(\d)\1+$/.test(digits)) {
            return false;
        }

        return true;
    }

    /**
     * Validate phone using intl-tel-input instance
     *
     * @since 1.2.1
     * @param {jQuery} $field
     * @return {Boolean}
     */
    function isValidIntlPhone($field) {
        if (
            !window.intlTelInputGlobals ||
            typeof window.intlTelInputGlobals.getInstance !== 'function'
        ) {
            return true; // intl-tel-input not available — allow validation fallback
        }

        var instance = window.intlTelInputGlobals.getInstance($field[0]);

        if (!instance || typeof instance.isValidNumber !== 'function') {
            return true;
        }

        return instance.isValidNumber();
    }

    /**
     * Init ticket helper
     *
     * @since 1.0.0
     * @version 1.2.1
     */
    function init() {
        refreshFieldIds();
        loadCachedValues();
        bindCacheHandlers();
        bindStepValidation();
        bindIntlPhoneFullHandlers();

        /**
         * Handle incremental ticket rendering on fragment update
         *
         * @since 1.2.1
         * @version 1.2.2
         */
        $(document.body).on('updated_checkout', function(event, data) {
            if (!data || !data.fragments) {
                return;
            }

            var wrapper = $('.flexify-ticket-fields');

            if (data.fragments.flexify_ticket_append) {

                // Append the new ticket group HTML
                wrapper.append(data.fragments.flexify_ticket_append);

                // Refresh tracking
                refreshFieldIds();
                bindCacheHandlers();

                // Re-initialize intl-tel-input for new fields
                Flexify_Checkout.Fields.internationalPhone();

                // Sync "_full" hidden field handler
                bindIntlPhoneFullHandlers();
            }

            var expected = parseInt(data.fragments.flexify_ticket_count, 10);
            var rendered = wrapper.find('.single-ticket-fields').length;

            wrapper.attr('data-ticket-count', expected);

            if (rendered > expected) {
                wrapper.find('.single-ticket-fields').slice(expected).remove();
            }
        });
    }

    $(init);
})(window, jQuery);